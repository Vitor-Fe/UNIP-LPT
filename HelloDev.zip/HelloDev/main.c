#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("Hey hi how're ya");
	return 0;
}
