#include <stdio.h>

/*int main()
{
    for (int i = 0; i < 10; i++)
    {
        printf("Here we go again\n");
    }
    return 0;
}
*/

/*int main()
{
    int i = 0;	// 1 int = 4 byte :)
    int M1[10]; //Cria uma vari�vel com espa�o para 10 inteiros (array);
    
    while (i < 10)
    {
        M1[i] = i;
        printf("M1[%d]=%d\n", i, M1[i]);
        ++i;
    }

    return 0;
}*/

int main()
{
    int i = 5;
    int a = 0;
    printf("a= %d\n", a);
    printf("i= %d\n", i);
    a = --i;
    printf("a= %d\n", a);
    printf("i= %d\n", i);
    return 0;
}