#include <stdio.h>
/*
int N1 = 1;
int N2 = 2;

int main()
{
    if(N1 > N2)
    {
        printf("N1 ser maior que N2.\n");
    }
    else
    {
        if(N2 > N1)
        {
            printf("N2 ser maior que N1.\n");
        }
        else
        {
            printf("N1 ser igual a N2.\n");
        }
    }
    return 0;
}
*/

/*
int main()
{
    int testInteger;
    printf("coloca um numero ai: ");
    scanf_s("%d", &testInteger);
    printf("Numero = %d", testInteger);
    return 0;
}*/


int N1;
int N2;

int main()
{
    printf("~ Comparador de Numeros ~\n");
    printf("\nInsira um numero: ");
    scanf_s("%d", &N1);
    printf("Insira outro numero: ");
    scanf_s("%d", &N2);
    printf("\nResultado: ");
    if(N1 > N2)
    {
        printf("N1 maior que N2 (%d > %d).\n", N1, N2);
    }
    else
    {
        if(N2 > N1)
        {
            printf("N2 maior que N1 (%d > %d).\n", N2, N1);
        }
        else
        {
            printf("N1 igual a N2 (%d = %d).\n", N1, N2);
        }
    }
    return 0;
}