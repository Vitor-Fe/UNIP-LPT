#include <stdio.h>

int N1 = 0;

int main()
{
    for (int a = 1; a < 10; a++)
    {
        N1 = 0;
        printf("Tabuada do %d: ", a);
        for (int i = 1; i < 10; i++)
        {
            N1 = a * i;
            printf("%d ", N1);
        }
        printf("\n");
    }
}